<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>

<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">Create Users</div>
            </div>
            <div class="col-auto">
                <a href="/admin/user/" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
            </div>
        </div>
    </div>

<div class="card-body">
    <div class="row">			
		<form class="" action="/admin/user/create" method="post" id="myForm" >
			<div class="row">
				<div class="col-12 col-sm-6">
					<div class="form-group  ">
						<input type="text" class="form-control" name ="firstname" id="firstname" value="<?= set_value('firstname');?>" placeholder="First Name">
						
						</div>
					</div>
					<div class="col-12 col-sm-6  mb-3">
						<div class="form-group">
							<input type="text" class="form-control" name ="lastname" id="lastname" value="<?= set_value('lastname');?>" placeholder="Last Name">
						
						</div>
					</div>
					<div class="col-12 col-sm-6  mb-3">
						<div class="form-group">
							<input type="text" class="form-control" name ="email" id="email" value="<?= set_value('email');?>" placeholder="Enter your Email">
							<small>must be a Uniq for every employee</small>
						
						</div>
						</div>
						<div class="col-12 col-sm-6 mb-3">
							<div class="form-group">
								<input type="tel" class="form-control" name ="mobile" id="mobile" value="<?= set_value('mobile');?>" placeholder="Mobile No "  pattern="[0-9]{3}[0-9]{7}" required>
								<small>Format: 0774567890</small>
							</div>
						</div>
								
						<div class="col-12 col-sm-4  mb-3">
							<div class="form-group">
								<input type="password" class="form-control" name ="password" id="passwd" value="" placeholder="Password ">
								<small> Use 8 or more characters with a mix of letters, numbers & symbols </small>
							</div>
						</div>
						<div class="col-12 col-sm-4 mb-3">
							<div class="form-group">
								<input type="password" class="form-control" name ="cpassword" id="cpasswd" value="" placeholder="Confirm ">
								<small> Use 8 or more characters with a mix of letters, numbers & symbols </small>
							</div>
						</div>
						
						<div class="col-12 col-sm-4  mb-3">
							 <div class="form-group">
							   
							    <select class="form-control form-control" id="role" name='role' value="male"<?= set_value('gender','role');?>>
							      <option class="col-12"></option>
							      <option class="col-12">Admin</option>
							      <option>Manager</option>
								  <option>Employee</option>				    
							    </select>
							    <small> System Role </small>
							  </div>
						</div>
						
						
						<?php if (isset($validation)): ?>
						<div class="col-12">
							<div class="alert alert-danger" role="alert">
								<?= $validation->listErrors(); ?>
							</div>
						</div>
						<?php endif; ?>
					</div>
					<hr>

					<div class="col-12 col-sm-12">
					 	<input type="submit" class="btn btn btn-primary bg-gradient border rounded-0" value="Save User" id="sbmitBtn">
            		</div>

				</div>
			</form>
		</div>
	</div>
</div>

<?= $this->endSection() ?>



