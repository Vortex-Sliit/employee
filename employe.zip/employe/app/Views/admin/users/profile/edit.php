<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>

<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
	<?php if (session()->get('sucess')): ?>
	<div class="alert alert-success" role="alert">
		<?= session()->get('sucess')?>
	</div>
	<?php endif; ?>
	<hr>

<div class="card shadow">

<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder"><?= $user['firstname']." ".$user['lastname']?>'s Profile  </div>
            </div>
            <small> 
           <div class="col-auto">
                <a href="/admin/user/" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
            </div>
        </div>

    </div>

<div class="card-body">

<form action="/admin/user/profile/edit/<?= $employee['empno']?>" method="post" enctype="multipart/form-data">
		<div class="row">
			
			<lable>Personal Details </lable> 
			<hr class="mt-3">
			<div class="form-check">
						<input class="form-check-input" type="radio" name="gender" id="gender" value="male"<?= set_value('gender','male');?>>
						<label class="form-check-label" for="gender">Male</label>
					</div>

				<div class="col-12 col-sm-3">
				<div class="form-group">
					
					 <input type="date" name="date_of_birth" max="2005-01-01" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth',$user['date_of_birth']);?>">
					
				</div>
				<small>employee's deate of birth </small>
				</div>

			<div class="col-12 col-sm-3">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="nationalid" id="nationalid" value="<?= set_value('nationalid',$user['nationalid']);?>" placeholder="National Id number">
					
				</div>
				<small>national id number</small>
			</div>
			
			<div class="col-12 col-sm-3">
				<div class="form-group">
						
						<input type="file" name="profileimg" value="<?= set_value('profileimg',$user['profileimg']);?>" />
						<small> please upload your nic image  </small>
				</div>
			</div>

			
			<hr class="mt-3">
			<div class="col-12 col-sm-4">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="address" id="address" value="<?= set_value('address',$user['address']);?>"placeholder="Address">
				
				</div>
				<small> employee's address</small>
			</div>	

			<div class="col-12 col-sm-4">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="contact_person" id="firstname" value="<?= set_value('contact_person',$user['contact_person']);?>"placeholder="Contact person">
									</div>
					<small> emegerncy contact person </small>
			</div>
			<div class="col-12 col-sm-4">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="emagency_contact" id="emagency_contact" value="<?= set_value('emagency_contact',$user['emagency_contact']);?>"placeholder="Contact No">
									</div>
									<small> emegerncy contact number </small>
			</div>

			<lable class="mt-3">Education Details </lable> 
			<hr class="mt-3">
		
			<div class="col-12 col-sm-3">
				<div class="form-group">
					<select class="form-control" id="qulifications" name="qulifications" value="" onchange=''>
							<option value=<?= set_value('qulifications',$user['qulifications']);?>> Select education  </otpion>
							<option value=1> No Education</option>
							<option value=2> Grade 5 </option>
							<option value=3> Grade 8</option>
							<option value=4> Up to GCE OL</option>
							<option value=5> Passed G.C.E OL</option>
							<option value=6> Up to GCE AL </option>
							<option value=7> Passed G.C.E AL </option>
							<option value=8> Undergraduate </option>
							<option value=9> Basic Degree </option>
							<option value=10> Basic Degree </option>
					</select>
				</div>
				<small> select  your highest qulifications </small>
			</div>
			
			<div class="col-12 col-sm-3">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="hometel" id="firstname" value="<?= set_value('hometel');?>"placeholder="Experience field">
									</div>
					<small>type your experience field</small>
			</div>

			<div class="col-12 col-sm-3">
				<div class="form-group">
					<select class="form-control" id="job_status" name="job_status" onchange='' value="<?= set_value('job_status','job_status');?>">
							<option>Job status </otpion>
							<option value=1> Entry-Level</option>
							<option value=2> Junior </option>
							<option value=2> Intermediate </option>
							<option value=3> Senior</option>
							<option value=4> Lead</option>
							<option value=4> Expert</option>
						
							
					</select>
				</div>
				<small> select  your highest job status  </small>
			</div>
			

			<div class="col-12 col-sm-3">
			<div class="form-group">
								
							   
     							<div class="form-outline" ">
    							<input min="0" max="50" type="number" name="" id=" typeNumber" class="form-control"  value="<?= set_value('job_status','job_status');?>"/>
							</div>
							<small>expeirence in no years </small>
			</div>
			</div>

			<hr class="mt-3">
			
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
					 <input type="date" name="apointment_date" max="2005-01-01" min="1960-01-01" class="form-control" value="<?= set_value('apointment_date',$user['apointment_date']);?>">
					
					
					
				</div>
				<small>select from  appoinment date </small>
			</div>
			
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
					<select class="form-control" id="desingation" name="depatment" onchange=''
					value="<?= set_value('depatment','depatment');?>">
							<option> Department</otpion>
								
							<option value="Information Technology"> Information Technology</option>
							<option value="Human Resources"> Human Resources</option>
							<option value="Accounting"> Accounting</option>
							<option value="Admin"> Admin </option>
							<option value="Sales"> Sales</option>
							
							
					</select>
				</div>
				<small>select  appoinment department </small>
			</div>
				<div class="col-12 col-sm-3 mt-3">
				<div class="form-group">
					<select class="form-control" id="desingation" name="designation" onchange='' value="<?= set_value('designation','designation');?>">
							<option> Designation</otpion>
							<option value=1> Cleark</option>
							<option value=2> Manager</option>
							<option value=3> Accountant</option>
							<option value=4> Execuctive </option>
							<option value=5> Minar Staff</option>
							<option value=6> Other </option>
							
					</select>
				</div>
				<small> select appoint desingation  </small>
			</div>
			
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="basic_salary" id="basic_salary" value="<?= set_value('basic_salary',$user['basic_salary']);?>"placeholder="Basic Salary">
									</div>
									<small> basic salary  </small>
			</div>
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="empno" id="empno" value="<?= set_value('empno');?>"placeholder="employeeno">
									</div>
									<small> employee no    </small>
			</div>
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="moreinfo" id="moreinfo" value="<?= set_value('moreinfo');?>"placeholder="more informaiton">
									</div>
									<small> more informaiton   </small>
			</div>

			<?php if (isset($validation)): ?>
				<div class="col-12">
					<div class="alert alert-danger" role="alert">
						<?= $validation->listErrors(); ?>
					</div>
				</div>
			<?php endif; ?>

			<div class="col-12 col-sm-12 mt-3">
					 <input type="submit" class="btn btn-primary float-right " value="Save Profile">
			</div>
</form>



</div>

</div>



<?= $this->endSection() ?>
