<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
 <div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
    


        <div class="card shadow">
        
        <div class="card-header">
                <div class="d-flex w-100 justify-content-between">
                    <div class="col-auto">
                        <div class="card-title h4 mb-0 fw-bolder"><?= $profile['firstname'] ?> <?= $profile['lastname']?>'s Summary Report </div>
                    </div>
        
                    
                   <div class="col-auto">
                        <a href="/admin/payroll/view" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
                    </div>
                </div>
        
            </div>
        
        <div class="card-body">     
                <div class="container mt-5 mb-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center lh-1 mb-2">
                        <h2 class="fw-bold"> Vortext International </h2>
                        <h4 class="fw-bold">Payslip</h4> <span class="fw-normal">payment slip for the month  year </span>
                    </div>
                    <div class="row mt-5">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-6">

                                    <div> <span class="fw-bolder">EMP Code</span> <small class="ms-3"><?= $profile['empno']+19000 ?></small> </div>
                                </div>
                                <div class="col-md-6 text-end">
                                    <div> <span class="fw-bolder">EMP Name</span> <small class="ms-3"><?= $profile['firstname'] ?> <?= $profile['lastname'] ?> </small> </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div> <span class="fw-bolder">Working Department:</span> <small class="ms-3"></small><?= $profile['depatment'] ?></div>
                                </div>
                                <div class="col-md-6 text-end">
                                    <div> <span class="fw-bolder">Mode of Pay</span> <small class="ms-3">S.B.I</small> </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div> <span class="fw-bolder">Designation</span> 
                                   
                                        <?php if(($profile['designation'])==1): ?>
                                           <small class="ms-3">Cleark </small> 
                                        <?php elseif(($profile['designation'])==2): ?>
                                           <small class="ms-3">Manager </small> 
                                        <?php elseif(($profile['designation'])==3): ?>
                                           <small class="ms-3">Accountant </small> 
                                        <?php elseif(($profile['designation'])==4): ?>
                                           <small class="ms-3">Execuctive </small> 
                                        <?php elseif(($profile['designation'])==5): ?>
                                           <small class="ms-3">Minar Staff </small> 
                                        <?php else: ?>
                                        <small class="ms-3">Other </small> 
                                        <?php endif ?>

                                   </div>
                                </div>
                                <div class="col-md-6 text-end">
                                    <div> <span class="fw-bolder">Ac No.</span> <small class="ms-3">*******0701</small> </div>
                                </div>
                            </div>
                        </div>
                        <table class="mt-4 table table-bordered">
                            <thead class="bg-secondary text-white">
                                <tr>
                                    <th scope="col">Earnings</th>
                                    <th scope="col">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <th scope="row">Basic Salary</th>
                                    <td><?= $basic_salary ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Allowances</th>
                                    <td><?= $allowances ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">OT</th>
                                    <td><?= $ot ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Gross Pay</th>
                                    <td><?= $grosspay ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Deductions</th>
                                    <td><?= $deduction ?></td>
                                </tr>
                                
                                <tr class="border-top">
                                    <th scope="row">Net Salary</th>
                                    <th><?= $netsalary ?></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <div class="d-flex flex-column mt-2"> <span class="fw-bolder">
                            
                        </span>  </div>
                    </div>
                   
                </div>
            </div>
        </div>
        
        </div>
        </div>
        </div>


<?= $this->endSection() ?>



