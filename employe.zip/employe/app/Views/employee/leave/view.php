<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder"><?= $emp_dis['firstname']?> <?= $emp_dis['lastname'] ?> Leaved Apply</div>
            </div>
            <div class="col-auto">
                <a href="/employee/leave/create" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Apply for leave</a>
            </div>
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">
<!-- Search Bar --> 
<div class="">
<input class="form-control" id="myInput" type="text" placeholder="Search..">
<small> you can filter users by typing any word in the table </small>
</div>


 

</br>
<?php if ($users) :?>
 <table class="table table-bordered table-striped">
<thead class="thead-light bg-warning">
<tr>
      <th> ID# </th>
      <th> User Full Name  </th>
      
      <th> Date of Apply </th>

      <th> is approved </th>
      <th> Approved by </th>
      <th> Action </th>
     

</tr>
</thead>
<tbody id="myTable">
<?php foreach($users as $user){ ?>
<tr>
  <td> <?= $user['id']?>  </td>
  <td> <?=$user['firstname']?>  <?=$user['lastname'] ?>  </td>
  
  <td> <?=$user['date_apply']?>  </td>

  <td> <?php if($user['is_approved']==1): ?> 
        <small class="badge bg-success">Leave Approved</small>
       <?php elseif($user['is_approved']==2): ?> 
        <small class="badge bg-danger">Leave Reject</small>
       <?php else:?> 
        <small class="badge  bg-warning">Pending </small>
       <?php endif;?>  

   </td>
  <td> <?=$user['approved_by']?>  </td>

  
    <?php  if ($user['status']==0){ ?>
    <td> <a href="/admin/user/profile/create/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="view more about users">Add</a> 
    <?php } else { ?>
    <td> <a href="/user/profile/view/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="view more about users">View</a> 
    <?php }?>


</tr>
<?php } ?>
</tbody>
</table>
<?php else:?>
<p> There are no courses Available for apply  </p>
<?php endif;?>
</div>




</div>
</div>
</div>
<?= $this->endSection() ?>






