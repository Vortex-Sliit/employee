<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>

<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
	<?php if (session()->get('sucess')): ?>
	<div class="alert alert-success" role="alert">
		<?= session()->get('sucess')?>
	</div>
	<?php endif; ?>
	<hr>

<div class="card shadow">

<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder"><?= $user['firstname']." ".$user['lastname']?>'s Profile  </div>
            </div>
            <small> 
           <div class="col-auto">
                <a href="/admin/user/" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> back</a>
            </div>
        </div>

    </div>

<div class="card-body">

<form action="/admin/user/profile/create/<?= $user['id']?>" method="post" enctype="multipart/form-data">
		<div class="row">
			
			<lable>Personal Details </lable> 
			<hr class="mt-3">
			<div class="col-12 col-sm-3">
				<div class="form-group">
					
					<div class="form-check">
						<input class="form-check-input" type="radio" name="gender" id="gender" value="male"<?= set_value('gender','male');?>>
						<label class="form-check-label" for="gender">Male</label>
					</div>

						
				<div class="form-check">
					<input class="form-check-input" type="radio" name="gender" id="gender" value="female"<?= set_value('gender','female');?>>
					<label class="form-check-label" for="gender"> Female </label>
				</div>
				<small> select the employee gender </small>
				</div>
				</div>
			
				<div class="col-12 col-sm-3">
				<div class="form-group">
					
					 <input type="date" name="date_of_birth" max="2005-01-01" min="1960-01-01" class="form-control" value="<?= set_value('date_of_birth');?>">
					
				</div>
				<small>employee's deate of birth </small>
				</div>		

			<div class="col-12 col-sm-3">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="nationalid" id="nationalid" value="<?= set_value('nationalid');?>" placeholder="National Id number">
					
				</div>
				<small>national id number</small>
			</div>
			
			<div class="col-12 col-sm-3">
				<div class="form-group">
						
						<input type="file" name="nicimage" value="<?= set_value('nicimage');?>" />
						<small> please upload your nic image  </small>
				</div>
			</div>

			
			<hr class="mt-3">
			<div class="col-12 col-sm-4">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="address" id="address" value="<?= set_value('address');?>"placeholder="Address">
				
				</div>
				<small> employee's address</small>
			</div>	

			<div class="col-12 col-sm-4">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="contact_person" id="firstname" value="<?= set_value('contact_person');?>"placeholder="Contact person">
									</div>
					<small> emegerncy contact person </small>
			</div>
			<div class="col-12 col-sm-4">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="emagency_contact" id="emagency_contact" value="<?= set_value('emagency_contact');?>"placeholder="Contact No">
									</div>
									<small> emegerncy contact number </small>
			</div>

			<lable class="mt-3">Education Details </lable> 
			<hr class="mt-3">
		
			<div class="col-12 col-sm-3">
				<div class="form-group">
					<select class="form-control" id="qulifications" name="qulifications" onchange=''>
							<option> Select education  </otpion>
							<option value=1> No Education</option>
							<option value=2> Grade 5 </option>
							<option value=3> Grade 8</option>
							<option value=4> Up to GCE OL</option>
							<option value=5> Passed G.C.E OL</option>
							<option value=6> Up to GCE AL </option>
							<option value=7> Passed G.C.E AL </option>
							<option value=8> Undergraduate </option>
							<option value=9> Basic Degree </option>
							<option value=10> Basic Degree </option>
					</select>
				</div>
				<small> select  your highest qulifications </small>
			</div>
			
			<div class="col-12 col-sm-3">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="hometel" id="firstname" value="<?= set_value('hometel');?>"placeholder="Experience field">
									</div>
					<small>type your experience field</small>
			</div>

			<div class="col-12 col-sm-3">
				<div class="form-group">
					<select class="form-control" id="job_status" name="job_status" onchange=''>
							<option>Job status </otpion>
							<option value=1> Entry-Level</option>
							<option value=2> Junior </option>
							<option value=2> Intermediate </option>
							<option value=3> Senior</option>
							<option value=4> Lead</option>
							<option value=4> Expert</option>
						
							
					</select>
				</div>
				<small> select  your highest job status  </small>
			</div>
			

			<div class="col-12 col-sm-3">
			<div class="form-group">
								
							   
     							<div class="form-outline" ">
    							<input min="0" max="50" type="number" id="typeNumber" class="form-control" />
							</div>
							<small>expeirence in no years </small>
			</div>
			</div>

			<hr class="mt-3">
			
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
					
					 <input type="date" name="appointdate" max=	min="2023-05-01" class="form-control" value="<?= set_value('appointdate');?>">
					
				</div>
				<small>select from  appoinment date </small>
			</div>
			
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
					<select class="form-control" id="desingation" name="depatment" onchange=''
					value="<?= set_value('depatment');?>">
							<option> Department</otpion>
								
							<option value="Information Technology"> Information Technology</option>
							<option value="Human Resources"> Human Resources</option>
							<option value="Accounting"> Accounting</option>
							<option value="Admin"> Admin </option>
							<option value="Sales"> Sales</option>
							
							
					</select>
				</div>
				<small>select  appoinment department </small>
			</div>
				<div class="col-12 col-sm-3 mt-3">
				<div class="form-group">
					<select class="form-control" id="desingation" name="designation" name="designation" onchange=''>
							<option> Designation</otpion>
							<option value=1> Cleark</option>
							<option value=2> Manager</option>
							<option value=3> Accountant</option>
							<option value=4> Execuctive </option>
							<option value=5> Minar Staff</option>
							<option value=6> Other </option>
							
					</select>
				</div>
				<small> select appoint desingation  </small>
			</div>
			
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
					
					<input type="text" class="form-control" name ="basic_salary" id="basic_salary" value="<?= set_value('basic_salary');?>"placeholder="Basic Salary">
									</div>
									<small> basic salary  </small>
			</div>
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="empno" id="empno" value="<?= set_value('empno');?>"placeholder="employeeno">
									</div>
									<small> employee no    </small>
			</div>
			<div class="col-12 col-sm-4 mt-3">
				<div class="form-group">
				
					<input type="text" class="form-control" name ="moreinfo" id="moreinfo" value="<?= set_value('moreinfo');?>"placeholder="more informaiton">
									</div>
									<small> more informaiton   </small>
			</div>

			<?php if (isset($validation)): ?>
				<div class="col-12">
					<div class="alert alert-danger" role="alert">
						<?= $validation->listErrors(); ?>
					</div>
				</div>
			<?php endif; ?>

			<div class="col-12 col-sm-12 mt-3">
					 <input type="submit" class="btn btn-primary float-right " value="Save Profile">
			</div>
</form>



</div>

</div>



<?= $this->endSection() ?>
