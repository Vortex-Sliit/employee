<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                 <div class="card-title h4 mb-0 fw-bolder">Leave Requests</div>
            </div>
           
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">
<?php if ($leave) :?>
<!-- Search Bar --> 
<div class="">
<input class="form-control" id="myInput" type="text" placeholder="Search..">
<small> you can filter users by typing any word in the table </small>
</div>


 

</br>

 <table class="table table-bordered table-striped">
<thead class="thead-light">
<tr>
      <th> ID# </th>
      <th> Employee Number </th>
      <th> User Full Name  </th>
      
      <th> Date of Apply </th>

      <th> Approval</th>
     
      <th class="text-center"> Action </th>
     

</tr>
</thead>
<tbody id="myTable">
<?php foreach($leave as $lve){ ?>
<tr>
  <td> <?= $lve['l_id'] ?>  </td>
  <td> <?= $lve['empno'] ?> </td>
  <td> <?=$lve['firstname']?>  <?=$lve['lastname'] ?>  </td>
  
  <td> <?=$lve['date_apply']?>  </td>

  <td> <?php if($lve['is_approved']==1): ?> 
        <small class="badge bg-success">Approved</small>
       <?php elseif($lve['is_approved']==2): ?> 
        <small class="badge bg-danger">Rejecteted</small>
       <?php else:?> 
        <small class="badge  bg-warning">Pending </small>
       <?php endif;?>  

   </td>
 

  
    <?php  if ($lve['is_approved']==0){ ?>
    <td> <a type="button" class="btn btn-primary" href="/manager/leave/accept/<?= $lve['l_id'] ?>">Approved</a> 
    <a type="button" class="btn btn-danger" href="/manager/leave/reject/<?= $lve['l_id'] ?>" ></i>Reject</a>
    <?php } else { ?>
    <td> <a href="/user/profile/view/<?=$lve['id'];?>" data-toggle="tooltip" data-placement="top" title="view more about users">View</a> 
    <?php }?>
 </td>

</tr>
<?php } ?>
</tbody>
</table>
<?php else:?>
<p> There are no leave  apply from any employee </p>
<?php endif;?>
</div>




</div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="ApprovedModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Leave Approval</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h4>Are you sure do you want to accept the Leave </h4>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <a type="button" class="btn btn-primary" href="/manager/leave/accept/<?= $lve['l_id'] ?> ">>Aproved</a>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="RejectModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Leave Reject</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h3> Leave was Rejected </h3>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <a type="button" class="btn btn-danger" href="/manager/leave/reject/<?= $lve['l_id'] ?>">Reject Leave</a>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>






