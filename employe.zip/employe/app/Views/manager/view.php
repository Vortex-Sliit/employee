<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?>
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">
<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">System Users</div>
            </div>
            <div class="col-auto">
                <a href="/admin/user/create" class="btn btn btn-primary bg-gradient border rounded-0"><i class="far fa-plus-square"></i> Add User</a>
            </div>
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">
<!-- Search Bar --> 
<div class="">


<small> System users can add, modify, and create an employee using this module. </small>
</div>


 

</br>
<?php if ($users) :?>

 <table id="mytable" class="table table-bordered table-striped table-responsive" >
<thead class="thead-light bg-warning">
<tr class="header">
      <th> ID# </th>
      <th> User Full Name  </th>
      
      <th> E-mail </th>

      <th> User Role </th>
      <th> Status </th>
     
      <th> Action </th>
     

</tr>
</thead>
<tbody>

<?php foreach($users as $user){ ?>
<tr>
  <td> <?= $user['id']?>  </td>
  <td> <?=$user['firstname']?>  <?=$user['lastname'] ?>  </td>
  
  <td> <?=$user['email']?>  </td>

  <td> 
    <?php if(($user['role'])=='admin'): ?>
    <span class="badge bg-primary shadow w-100"><?= $user['role']?> </span> 
    <?php elseif($user['role']=='Employee'): ?>
    <span class="badge bg-secondary shadow w-100"><?= $user['role']?> </span> 
    <?php else: ?>
    <span class="badge bg-info shadow w-100"><?=$user['role']?> </span> 
    <?php endif ?>
    
 </td>
 
</td>
  
  <?php  if ($user['active']!=0){

     ?>

    <td class="">
      <a class="" type="submit" href="/admin/user/activate/<?=$user['id'];?>"><i class="fa-solid fa-eye-slash"></i><small>activate</small></a>
     
 
    

  <?php  }
    else
    { ?>
      <td class="">
      <a class="" href="/admin/user/deactivate/<?=$user['id'];?>"><i class="fa-solid fa-eye"></i><small>deactive</small></a>
    

    </td>

    <?php } ?>
      
    <?php  if ($user['status']==0){ ?>
    <td> <a href="/admin/user/profile/create/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="view user profile">Add User Profile</a> 
    </td>
    <?php } else { ?>
    <td> 
    
    <a href="/admin/user/profile/edit/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="edit user profile"> <i class="fa-solid fa-user-pen" style="color: #9141ac;"></i> <small> Edit</small></a> 

    <!-- <a href="/edit_user/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="delete user and profile"> <i class="fa-solid fa-user-minus" style="color: #a51d2d;"></i> </a> -->

    <a href="/admin/user/profile/view/<?=$user['id'];?>" data-toggle="tooltip" data-placement="top" title="view more about users"><i class="fa-solid fa-play" style="color: #1a7d0d;"></i> <small> view </small> </a>  
    </td>
    <?php }?>
   


</tr>
<?php } ?>
</tbody>
</table>
<?php else:?>
<p> There are no courses Available for apply  </p>
<?php endif;?>
<?= $pager->links('default', 'front_full'); ?>
</div>

 


</div>
</div>
</div>

 
<?= $this->endSection() ?>

