<?= $this->extend('home/dashboard') ?>
<?= $this->Section('content') ?>
<?php
     if(isset($_SESSION['msg'])){
        echo $_SESSION['msg'];
      }
     ?> 
<div class="col-12 col-sm-12  pb-3 bg-white form-wrapper ">

<div class="card shadow">
<div class="card-header">
        <div class="d-flex w-100 justify-content-between">
            <div class="col-auto">
                <div class="card-title h4 mb-0 fw-bolder">Dahsboard</div>
            </div>
           
        </div>
    </div>

<div class="card-body">
        <div class="container-fluid">

<div class="row">
  <div class="col-12 mb-3">
<div class="card text-center">
  <div class="card-header">
    <h3 class="primary"> <i class="fa-solid fa-tornado"></i> Welcome Vortex HR System </h3>
  </div>
  <div class="card-body">
  
    <small class="card-text  ">This employee management software offers a comprehensive solution for HR departments, providing streamlined employee administration, performance tracking, leave management, and communication tools for efficient workforce management</small>
    
  </div>
</div>
  </div> 

</div>
<div class="row">
<div class="col-3 mb-3">

<div class="card text-center">
  <div class="card-header">
  <i class="fa-solid fa-users"></i> Employee 
  </div>
  <div class="card-body">
    <h3 class="card-title "><span class="badge bg-secondary"><?= $emp ?></span></h3>
    <small class="card-text">total number of employee </small>
    
  </div>
</div>
</div>
<div class="col-3 mb-3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-solid fa-user-group"></i> Monthly Target 
  </div>
  <div class="card-body">
    <h3 class="card-title"><span class="badge bg-secondary"><?= $manager ?></span></h3>
    <p class="card-text">number of managers</p>

  </div>
</div>
</div>
<div class="col-3 mb-3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-solid fa-user-group"></i> Leaves Apply
  </div>
  <div class="card-body">
    <h3 class="card-title"><span class="badge bg-secondary"><?= $admin ?></span></h3>
    <p class="card-text">no of desingations.</p>
    
  </div>
</div>
</div>
<div class="col-3 mb-3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-sharp fa-solid fa-people-group"></i> Weekly Tasks
  </div>
  <div class="card-body">
    <h3 class="card-title"><span class="badge bg-secondary"><?= $users ?></span></h3>
    <p class="card-text">no of system users.</p>
    
  </div>
</div>
</div>

<div class="col-3 mt=3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-solid fa-users"  style="color: #3584e4;"></i> Active Employees
  </div>
  <div class="card-body">
    <h3 class="card-title"><span class="badge  bg-primary"><?= $actemp ?></span></h3></h3>
    <p class="card-text">no of system users.</p>
    
  </div>
</div>
</div>

<div class="col-3 mt=3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-solid fa-user-group" style="color: #3584e4;"></i>  
  </div>
  <div class="card-body">
    <h3 class="card-title"><span class="badge  bg-primary"><?= $actemp ?></span></h3></h3>
    <p class="card-text">no of system users.</p>
    
  </div>
</div>
</div>


<div class="col-3 mt=3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-solid fa-user-group" style="color: #3584e4;"></i> No of Leaves  
  </div>
  <div class="card-body">
    <h3 class="card-title"><span class="badge  bg-primary"><?= $actemp ?></span></h3></h3>
    <p class="card-text">no of system users.</p>
    
  </div>
</div>
</div>
<div class="col-3 mt=3">
<div class="card text-center">
  <div class="card-header">
    <i class="fa-solid fa-user-group" style="color: #3584e4;"></i> Especiallity
  </div>
  <div class="card-body">
    <h3 class="card-title badge-primary"><span class="badge  bg-primary"><?= $actemp ?></span></h3>
    <p class="card-text">no of system users.</p>
    
  </div>
</div>
</div>
</div>
</div>
</div>
</div>






<?= $this->endSection() ?>



<script>
function myFunction() {
  // Declare variables
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = ul.getElementsByTagName('li');

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
</script>