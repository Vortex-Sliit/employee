<nav class="navbar navbar-expand-lg navbar-dark  bg-primary">
  <div class="container-fluid shadow">

    <a class="navbar-brand" href="#"><i class="fa-solid fa-tornado"></i> Votex International (PVT) Ltd. </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <ul class="navbar-nav flex-right">
     <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
             <?=session()->get('firstname')?> <?=session()->get('lastname')?>'s Account <i class="fa-solid fa-gear fa-spin-pulse" style="color: #eed144;"></i>
        

          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="/profile"><span class="glyphicon glyphicon-user"></span><i class="fa-solid fa-id-badge" style="color: #1a5fb4;"></i> <span class="ms-3">User Profile</a>
      <a class="dropdown-item" href="#"><i class="fa-solid fa-gears" style="color: #1a5fb4;"></i>  <span class="ms-3">Settings</a>
          </ul>
          
        </li>
      <li class="nav-item me-3 me-lg-1">
        <a class="nav-link" href="#">
          <span><i class="fas fa-plus-circle fa-lg"></i></span>
        </a>
      </li>
      
        
        
     
     
    </ul>
  </div>
</nav>
