<?php namespace App\Models;

use CodeIgniter\Model;

class PayrollModel extends Model
{
    protected $table = 'payroll';
    protected $primaryKey = 'p_id';
    protected $allowedFields = ['empno','allaownce','deduction','paid_date','create_at','updated_at','pay_period'];
 
  


public function get_payments_users()
        {
        
                


            $this->select('*');
              $this->join('user_profile','payroll.empno=user_profile.empno');
              $this->join('attendance','user_profile.empno=attendance.empno');
              $this->join('users','user_profile.uid=users.id');
              

             // $this->select('users.firstname,users.lastname,user_profile.basic_salary,allowance,deduction,pay_period,paid_date');

             $users = $this->get()->getResultArray();
             return $users;
       
             
        }

public function get_profile_empno($empno){

          
            $this->join('user_profile','payroll.empno=user_profile.empno');
            $this->join('users','user_profile.uid=users.id');
              $this->select('users.firstname,users.lastname,user_profile.basic_salary,user_profile.empno,user_profile.depatment,user_profile.designation');
              $this->where('user_profile.empno',$empno);
              $users = $this->first(); 
             return $users;
       

}

public function get_payroll($empno)
{
  
 return $this->asArray()->select('*')
                      ->where(['empno' => $empno])
                      ->first();
  }      


public function get_salaryformonth($id,$month){

   
            $this->join('user_profile','payroll.empno=user_profile.empno');
            $this->join('users','user_profile.uid=users.id');
               $this->select('users.firstname,users.lastname,user_profile.basic_salary,user_profile.empno,user_profile.depatment,user_profile.designation,payroll.allaownce,user_profile.empno');
              $this->where('users.id',$id);
              $this->where('pay_period',$month);
              $users = $this->first(); 
             return $users;
}

public function get_user_by_id($id){

    
            $this->join('users','user_profile.uid=users.id');
               $this->select('users.firstname,users.lastname,user_profile.basic_salary,user_profile.empno,user_profile.depatment,user_profile.designation,payroll.allaownce,user_profile.empno');
              $this->where('users.id',$id);
              
              $users = $this->first(); 
             return $users;
}
          
}