<?php namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['email','password','lastlogin','role','firstname','lastname','slug','mobile','status','updated_at','slug'];
    protected $beforeInsert = ['beforeInsert'];
    protected $beforeUpdate = ['beforeUpdate'];

  




    protected function beforeInsert(array $data)
      {
          $data = $this->passwordHash($data);
          return $data;
      }


    protected function beforeUpdate(array $data)
      {

       $data = $this->passwordHash($data);
       return $data;
      }


    protected function passwordHash(array $data)
      {
        if(isset($data['data']['password']))
        $data['data']['password']=password_hash( $data['data']['password'],PASSWORD_DEFAULT);
        return $data;
      }


      public function getusers($slug = false)
      {
          if ($slug === false)
          {
              
            return $this->orderBy('id','DESC')->findAll();
                          
          }
          return $this->asArray()
                      ->where(['slug' => $slug])
                      ->first();
       }

       public function getUserStatusById($id){

          return $this->db->table($this->table)
                ->where('id',$id)
                ->get()
                ->getRow();

       }

      public function get_empnof_from_id($id){

          if ($id)
         {

                return $this->asArray()->select('user_profile.empno')
                     ->where(['id' => $id])
                     ->first();
      }}

       

       public function change_status($id,$stat=1) 
       {
           $newdata=[];
            if ($stat==1){
            $newdata =
                    [
                      'id'  =>$id ,
                    'active'=>0,
                      'updated_at' => date('Y-m-d H:i:s',now()),
                    ];
         }
              else{

                $newdata =
                        [
                          'id'  =>$id ,
                        'active'=>1,
                          'updated_at' => date('Y-m-d H:i:s',now()),
                        ];

           }
                     $this->save($newdata);


         }


    public function employee_activated($id){

        

          $newdata =
                        [
                          'id'  =>$id ,
                        'active'=>1,
                        'status'=>1,
                          
                        ];

           
                     $this->save($newdata);
        }
    

      

       public function getuser_from_id($id)
     {
         if ($id)
         {

                return $this->asArray()->select('id,email,status,role,firstname,lastname,lastlogin')
                     ->where(['id' => $id])
                     ->first();
      }}

       public function getuser_from_email($email)
      {
          if ($email)
          {

                 return $this->asArray()->select('id,email,status,firstname,lastname,role')
                      ->where(['email' => $email])
                      ->first();
       }
     }



     public function get_users_empno()
        {
        
              
              $this->join('user_profile','user_profile.uid=users.id');
             
              $this->select('user_profile.empno,users.firstname,users.lastname');

             $users = $this->get()->getResultArray();
             return $users;
       
             
        }

      public function get_user_by_id($id){

         $this->join('user_profile','user_profile.uid=users.id');
             
         $this->select('user_profile.empno,users.firstname,users.lastname,user_profile.basic_salary,user_profile.depatment,user_profile.designation,users.role,user_profile.date_of_birth,user_profile.gender,mobile,user_profile.address,user_profile.profileimg,email,user_profile.gender,user_profile.nationalid,user_profile.contact_person,user_profile.emagency_contact,user_profile.qulifications,user_profile.apointment_date ');
         $this->where('id',$id);
         $users = $this->first(); 
         return $users;


      }

      public function count_query($qry){

        
    $this->where('role', $qry);
    $query = $this->countAllResults() ;

    
    return $query;
      }


    public function active_employee(){

        
    $this->where('status', 1);
    $query = $this->countAllResults() ;

    
    return $query;
      }

        public function get_user_empno($id)
        {
        
              
              $this->join('user_profile','user_profile.uid=users.id');
             
              $this->select('user_profile.empno');

              $this->where('uid',$id);
              return $this->asArray()->first();
       
             
        }
          
}
