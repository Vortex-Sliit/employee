<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Users');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Login::index',['filter'=>'noauth']);
$routes->get('/dashboard', 'Home::index');
$routes->match(['get','post'],'/login', 'Login::login');
$routes->match(['get','post'],'/change_password', 'Users::user_chagne_password',['filter'=>'noauth']);
$routes->match(['get','post'],'/logout', 'Login::logout',['filter'=>'auth']);
 $routes->get('profile', 'Home::view_user_profiels',['filter'=>'auth']);
//$routes->get('/user', 'Users::index');
//$routes->get('/', 'Users::login');
//$routes->match(['get','post'],'/create_user', 'Users::create');
//$routes->get('/user','User::index');
//$routes->match(['get','post'],'/activate_user/(:num)', 'Users::activate_user/$1');
//$routes->match(['get','post'],'/deactivate_user/(:num)', 'Users::deactivate_user/$1');
//$routes->match(['get','post'],'/edit_user/(:num)', 'Users::edit_user/$1');
//$routes->match(['get','post'],'/payroll/view', 'Payroll::index');
/*

 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */



//==================Admin Dahsboard Routes====================================
$routes->group('admin',function($routes){
//================= Dashboard ================================================
     $routes->get('dashboard', 'Home::admin_dashboard',['filter'=>'auth']);
     $routes->get('user', 'Modules\Admin::system_users_view',['filter'=>'auth']); 

//================= User =====================================================
    $routes->group('user',function($routes){
             $routes->get('activate/(:num)', 'BaseClases\Users::activate_user/$1',['filter'=>'auth']);
            $routes->get('deactivate/(:num)', 'BaseClases\Users::deactivate_user/$1',['filter'=>'auth']);
            $routes->get('view/(:num)', 'Dashboard::user_profile_view/$1',['filter'=>'auth']);
            $routes->match(['get','post'],'create', 'BaseClasses\Users::create',['filter'=>'auth']);
            $routes->match(['get','post'],'edit/(:num)', 'BaseClases\Users::create_profile/$1',['filter'=>'auth']);

            $routes->group('profile',function($routes){
            $routes->get('view/(:num)', 'BaseClasses\Users::view_user_profiels/$1',['filter'=>'auth']);
            $routes->match(['get','post'],'create/(:num)', 'BaseClasses\Users::create_profile/$1',['filter'=>'auth']);
            $routes->match(['get','post'],'edit/(:num)', 'BaseClasses\Users::edit_profile/$1',['filter'=>'auth']);
            

            $routes->group('password',function($routes){
                $routes->match(['get','post'],'update', 'BaseClases\Users::user_chagne_password',['filter'=>'auth']);
            });

        });

       
        

        });

    $routes->group('leave', function($routes){

        $routes->get('create', 'Dashboard::user_student_create',['filter'=>'auth']);
        $routes->match(['get','post'],'create', 'User\Students::create_student',['filter'=>'auth']);
        $routes->get('view', 'Modules\Employee::request_leave_view',['filter'=>'auth']);
    });

    $routes->group('attendance', function($routes){
            $routes->get('view', 'Modules\Admin::user_attendance_view');
            $routes->match(['get','post'], 'create','BaseClasses\Attendance::create',['filter'=>'auth']);

    });
    $routes->group('payroll', function($routes){
            $routes->get('view','Modules\Admin::manage_payroll');    
            $routes->match(['get','post'], 'create','BaseClasses\Payroll::create',['filter'=>'auth']);
    $routes->match(['get','post'], 'calcuate','BaseClases\Payroll::calcuate_salary',['filter'=>'auth']);
   
    });
    $routes->group('report', function($routes){ 

            $routes->get('view', 'Modules\Admin::admin_reports',['filter'=>'auth']);
            $routes->get('apply', 'Dashboard::user_student_batch_apply',['filter'=>'auth']);
            $routes->get('days/(:num)/(:num)', 'Dashboard::user_batch_days_view/$1/$2',['filter'=>'auth']);
    //$routes->match(['get','post'], 'create','User\Users::create_child',['filter'=>'auth']);
    //  $routes->get('create', 'User\Parents::create_parent',['filter'=>'auth']);
    });
});
// ===============================================================================================




//=============================Employee Dahsboard Routes========================================

$routes->group('employee',function($routes){ 
   
     $routes->get('dashboard/', 'Home::employee_dashboard',['filter'=>'auth']);

    

    $routes->group('profile',function($routes){
        $routes->get('view/(:num)', 'Dashboard::user_profile_view/$1',['filter'=>'auth']);
    });
    $routes->group('leave',function($routes){
          $routes->get('view/', 'Modules\Employee::request_leave_view',['filter'=>'auth']);

      //  $routes->match(['get','post'], 'view','Leave::index',['filter'=>'auth']);
        $routes->match(['get','post'], 'create','BaseClasses\Leave::create_leave',['filter'=>'auth']);

        $routes->get('view/(:num)', 'BaseClases\Leave::view/$1',['filter'=>'auth']);
        $routes->match(['get','post'], 'create','BaseClases\Leave::create_leave',['filter'=>'auth']);
    //  $routes->match(['get','post'], 'create','Student\Batches::apply_for_batch',['filter'=>'auth']);
    });
    $routes->group('history',function($routes){
         $routes->get('view', 'Modules\Employee::emp_history_view',['filter'=>'auth']);
        $routes->get('view/(:num)', 'BaseClases\Attendance::view_emp/$1',['filter'=>'auth']);
        $routes->match(['get','post'], 'salary','Modules\Employee::emp_chk_salary_history',['filter'=>'auth']);
    });
   
    


});
// ===============================================================================================



//=============================Manager Dahsboard Routes========================================

$routes->group('manager',function($routes){

     $routes->get('dashboard', 'Home::manager_dashboard',['filter'=>'auth']);

    $routes->group('profile',function($routes){
        $routes->get('view/(:num)', 'Modules\Manager::user_profile_view/$1',['filter'=>'auth']);
    });


    $routes->group('leave',function($routes){
      
         $routes->get('leaverequest', 'BaseClasses\Leave::leave_requests',['filter'=>'auth']);
        $routes->get('accept/(:num)','BaseClasses\Leave::manage_leaave_accept/$1',['filter'=>'auth']);
        
        $routes->get('reject/(:num)','BaseClasses\Leave::manager_leave_reject/$1',['filter'=>'auth']);

   
    });
 
  
        $routes->group('report',function($routes){
        $routes->get('view', 'Modules\Manager::manager_report_view',['filter'=>'auth']);
    });
    
    


});
// ===============================================================================================



if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
