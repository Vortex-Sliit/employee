<?php

namespace App\Controllers\Modules;
use App\Controllers\BaseController;

use CodeIgniter\Controller;

use Psr\Log\LoggerInterface;
use App\Controllers\BaseClasses\Attendance;
use App\Controllers\BaseClasses\Leave;
use App\Controllers\BaseClasses\Payroll;
use App\Controllers\BaseClasses\Users;
use App\Controllers\BaseClasses\Reports;
use App\Models\UserModel;
use App\Models\UserProfileModel;
use App\Models\LeaveModel;
use App\Models\PayrollModel;
use App\Models\AttendanceModel;
$pager = \Config\Services::pager();



/**

    Class EmployeeController
    EmployeeController is responsible for handling operations related to employees.
    It extends the BaseController class, providing a convenient place for loading components
    and performing functions that are needed by all controllers.
    @extends BaseController
    **/

class Employee extends BaseController
{


    public function __construct()
    {
        helper('form');
        $this->user = new Users();
        $this->attendance = new Attendance();
        $this->payroll = new Payroll();
        $this->report = new Reports();
        $this->model = new UserModel();
        $this->employee= new UserProfileModel();
        $this->leave_model= new LeaveModel();
        $this->payroll_model = new PayrollModel();
        $this->attendance_model= new AttendanceModel();

        helper('date');
        
        
    }
    /*
    Display a employees dashboard
    @public
    */

    public function index()
    {
        $data['user'] = [session()->get('firstname'),session()->get('lastname')];
        $data['users']= $this->model->countAll();
        $data['actemp']= $this->model->active_employee();
        $data['emp']= $this->model->count_query('Employee');
        $data['admin']= $this->model->count_query('Admin');
        $data['manager']= $this->model->count_query('Manager');
        return  view("employee/emp_dashboard",$data);
    }

// edit employee profiel ========================================
    public function edit_profile(){


    }

// view all leave requests by the employee========================================
    public function request_leave_view(){

       $data['users'] = $this->leave_model->get_employee_leave(session()->get('id'));
        $data['emp_dis'] = $this->model->getuser_from_id(session()->get('id'));
        
        $this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("employee/leave/view",$data);

    }


    // view all leave requests by the employee========================================
    public function emp_history_view(){

       $data['users'] = $this->leave_model->get_employee_leave(session()->get('id'));
        $data['emp_dis'] = $this->model->getuser_from_id(session()->get('id'));
        
        $this->logger->info('Retrieved all users from the database.', $data['users']);
        return view("employee/emp_history_view",$data);

    }


//  add leave request from the system ========================================
    public function request_leave_create(){


    }


/// view employee history ========================================
    public function history_view(){
        

    }


// logout from the system 
    public function logout()
    {
        
    }


    public function emp_chk_salary_history(){
            $data = [];
            $data['month']="March";
            $data['users'] = $this->payroll_model->get_salaryformonth(session()->get('id'),$data['month']);
            $data['profile']=$this->payroll_model->get_profile_empno($data['users']['empno']);
            $data['payroll'] = $this->payroll_model->get_payroll($data['users']['empno']);
            $data['attend'] = $this->attendance_model->get_attednace($data['users']['empno']);
            $data['basic_salary'] = $data['profile']['basic_salary'];
            $data['allowances'] = $data['payroll']['allaownce'];
            $data['deduction'] = $data['payroll']['deduction'];
            $data['ot'] =$data['attend']*200;
            $data['grosspay'] = ($data['basic_salary']+$data['allowances']+$data['ot']*200);
                            $data['netsalary'] = ($data['grosspay']-$data['deduction']);

            return view("employee/history/salary/emp_salary_his_view",$data);;

    }


    
}
