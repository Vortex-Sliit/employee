-- phpMyAdmin SQL Dump
-- version 5.0.4deb2+deb11u1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 16, 2023 at 03:05 PM
-- Server version: 10.5.19-MariaDB-0+deb11u2
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `empno` int(11) NOT NULL,
  `dateofattend` date NOT NULL,
  `OT` int(11) NOT NULL,
  `a_id` int(11) NOT NULL,
  `emp_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`empno`, `dateofattend`, `OT`, `a_id`, `emp_status`) VALUES
(1, '2023-05-18', 1, 1, 3),
(3, '2023-05-10', 0, 2, 2),
(4, '2023-05-12', 0, 3, 1),
(8, '2023-05-10', 0, 4, 2),
(4, '2023-05-18', 0, 5, 3),
(8, '2023-05-16', 4, 6, 3),
(5, '2023-05-12', 4, 7, 3),
(3, '2023-05-03', 0, 8, 1),
(1, '2023-05-04', 0, 9, 1),
(5, '2023-05-11', 4, 10, 3),
(10, '2023-05-17', 0, 11, 3);

-- --------------------------------------------------------

--
-- Table structure for table `auth_logins`
--

CREATE TABLE `auth_logins` (
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `id_type` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL,
  `auth_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE `payroll` (
  `empno` int(11) NOT NULL,
  `allaownce` decimal(10,0) NOT NULL,
  `deduction` decimal(10,0) NOT NULL,
  `p_id` int(11) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `pay_period` enum('January','February','March','April','May','June','July','Augest','September','October','November','December','') NOT NULL,
  `paid_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`empno`, `allaownce`, `deduction`, `p_id`, `create_at`, `update_at`, `pay_period`, `paid_date`) VALUES
(3, '1000', '200', 1, '2023-05-12 10:36:35', '2023-05-12 10:37:56', 'April', '0000-00-00 00:00:00'),
(3, '1000', '200', 2, '2023-05-12 10:38:34', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00'),
(3, '1000', '200', 3, '2023-05-12 10:42:25', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00'),
(3, '1000', '200', 4, '2023-05-12 10:42:57', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00'),
(1, '2500', '200', 5, '2023-05-12 10:54:44', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 6, '2023-05-12 10:56:46', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 7, '2023-05-12 10:57:05', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 8, '2023-05-12 10:57:59', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 9, '2023-05-12 10:58:54', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 10, '2023-05-12 10:59:14', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 11, '2023-05-12 11:01:28', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 12, '2023-05-12 11:02:17', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 13, '2023-05-12 11:02:43', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 14, '2023-05-12 11:03:14', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(1, '2500', '200', 15, '2023-05-12 11:04:24', '0000-00-00 00:00:00', 'March', '0000-00-00 00:00:00'),
(4, '3434', '343', 16, '2023-05-13 19:58:11', '0000-00-00 00:00:00', 'May', '0000-00-00 00:00:00'),
(6, '3434', '343', 17, '2023-05-14 08:12:18', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(6, '3434', '343', 18, '2023-05-14 08:13:17', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(10, '1000', '2333', 19, '2023-05-15 05:47:43', '0000-00-00 00:00:00', 'May', '0000-00-00 00:00:00'),
(5, '1993', '3929', 20, '2023-05-15 17:53:43', '0000-00-00 00:00:00', 'June', '0000-00-00 00:00:00'),
(5, '1993', '3929', 21, '2023-05-15 18:11:07', '0000-00-00 00:00:00', 'June', '0000-00-00 00:00:00'),
(4, '2500', '200', 22, '2023-05-16 05:09:19', '0000-00-00 00:00:00', 'May', '0000-00-00 00:00:00'),
(3, '2500', '200', 23, '2023-05-16 05:13:17', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 24, '2023-05-16 05:17:18', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 25, '2023-05-16 05:18:19', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 26, '2023-05-16 05:18:24', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 27, '2023-05-16 05:20:08', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 28, '2023-05-16 05:21:00', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 29, '2023-05-16 05:22:49', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 30, '2023-05-16 05:24:14', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 31, '2023-05-16 05:24:56', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 32, '2023-05-16 05:28:13', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 33, '2023-05-16 05:36:46', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 34, '2023-05-16 05:37:40', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 35, '2023-05-16 05:40:22', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 36, '2023-05-16 05:44:08', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 37, '2023-05-16 05:44:39', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 38, '2023-05-16 05:46:41', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 39, '2023-05-16 05:47:20', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 40, '2023-05-16 05:47:34', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(3, '2500', '200', 41, '2023-05-16 05:49:12', '0000-00-00 00:00:00', 'April', '0000-00-00 00:00:00'),
(4, '1000', '345', 42, '2023-05-16 06:08:13', '0000-00-00 00:00:00', 'July', '0000-00-00 00:00:00'),
(6, '3233', '456', 43, '2023-05-16 06:09:03', '0000-00-00 00:00:00', 'May', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leave`
--

CREATE TABLE `tbl_leave` (
  `empno` int(11) NOT NULL,
  `date_apply` date NOT NULL,
  `is_approved` int(1) NOT NULL,
  `approved_by` int(11) NOT NULL,
  `l_id` int(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `reason` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_leave`
--

INSERT INTO `tbl_leave` (`empno`, `date_apply`, `is_approved`, `approved_by`, `l_id`, `type`, `reason`) VALUES
(4, '2023-05-12', 1, 12, 2, '', ''),
(4, '2023-05-19', 2, 12, 3, '', ''),
(10, '2023-05-17', 1, 12, 4, '', ''),
(10, '2023-05-17', 0, 0, 5, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `status` varchar(255) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `last_active` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` enum('Admin','User','Manager','Employee') NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `password` varchar(500) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `lastlogin` datetime NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`status`, `status_message`, `active`, `last_active`, `created_at`, `updated_at`, `deleted_at`, `firstname`, `lastname`, `email`, `role`, `mobile`, `password`, `slug`, `lastlogin`, `id`) VALUES
('1', '1', 0, NULL, '2023-05-08 09:54:25', '2023-05-16 14:05:12', NULL, 'Sumudu', 'Saranga', 'sumudu.susahe@gmail.com', 'Admin', '0773051133', '$2y$10$ivNlcgJpg2p/5pTr0htlz.ybDfeRqDPwd3FJCZYPEcg1xip.2aUAi', 'sumudususahegmailcom', '2023-05-16 08:35:12', 1),
('1', NULL, 1, NULL, '2023-05-12 15:22:09', '2023-05-16 13:42:31', NULL, 'Saranga', 'Hettiarachchi', 'saranga@gmail.com', 'Manager', '0773051133', '$2y$10$gS4T/MgP5ELDBnFx3GOXDuAeg0cp2WVyNjqHLGfVdatlZDF2/tc1.', 'sarangagmailcom', '2023-05-16 08:12:31', 12),
('1', '1', 1, NULL, '2023-05-12 15:22:48', '2023-05-14 11:01:04', NULL, 'Kumari', 'Wathsala', 'kumari@gmail.com', 'Employee', '0773051132', '$2y$10$FwuPlGf4/SgdFtK/BNoMcOBvlqegqwTzyAiBQeYnRU4iPKJeGkBjS', 'kumarigmailcom', '2023-05-14 05:31:04', 13),
('1', NULL, 1, NULL, '2023-05-12 15:45:28', '2023-05-14 22:26:34', NULL, 'Vijith Rohana', 'Kumarasiri', 'vijitharohana@gmail.com', 'Employee', '0773051133', '$2y$10$QJCvpIH7aAqDH6q0aAhU9es76wRJJ/PFJ55cUqljH6h6TD82E7tQ6', 'vijitharohanagmailcom', '2023-05-14 16:56:34', 14),
('1', NULL, 0, NULL, '2023-05-12 15:48:14', '2023-05-12 15:49:03', NULL, 'saman', 'Kumarasiri', 'sama@kumara.lk', 'Admin', '0773051132', '$2y$10$H7JUzPZK6dheKbZIYqmWv.N8ZrZUhVR8TKgEawTpgBs4Wz86uAsY6', 'samakumaralk', '0000-00-00 00:00:00', 15),
('1', NULL, 0, NULL, '2023-05-12 15:50:25', '2023-05-12 15:53:06', NULL, 'Rajitha', 'Silva', 'rjai@gmail.com', 'Employee', '0738383833', '$2y$10$f.nrDybeEScAzlv9WNOIV.uDFC1BAHsWeZDjxsOXm7jtLllzEQZlG', 'rjaigmailcom', '0000-00-00 00:00:00', 16),
('1', NULL, 0, NULL, '2023-05-13 22:03:30', '2023-05-13 19:25:52', NULL, 'Vipula ', 'Silva', 'vipula@gmail.com', 'Employee', '0773051133', '$2y$10$Wrj89PHQzfUidvTQTeXcReXzQ6oZarwPuilmYot8OGGvsvsjwpOxW', 'vipulagmailcom', '0000-00-00 00:00:00', 17),
('1', NULL, 0, NULL, '2023-05-13 22:04:38', '2023-05-13 19:25:49', NULL, 'Ranjith', 'Bandara', 'ranjith@gmail.com', 'Employee', '0773051133', '$2y$10$4VvngPhATEWPs4DeqNmup.5/HD7OoTp0T5dBNSkBVaY66Mfh9D8Ju', 'ranjithgmailcom', '0000-00-00 00:00:00', 18),
(NULL, NULL, 0, NULL, '2023-05-14 12:29:00', NULL, NULL, 'Saman', 'Kumara', 'smankumara@gmail.com', 'Employee', '3234324333', '$2y$10$dXB8Fsw1/FV3zrYPtwk4R.WSC/OnbtYWnZw/fyVNv.Jc8oByDhHYu', 'smankumaragmailcom', '0000-00-00 00:00:00', 19),
(NULL, NULL, 0, NULL, '2023-05-14 12:29:41', NULL, NULL, 'Kamal', 'vimal', 'kamal@gmail.com', 'Employee', '0773051135', '$2y$10$sWVDuM6Ra9PKIimUV1OkO.y.4mI30CWHiVLI/WpGXU5Qx3rYjFDgO', 'kamalgmailcom', '0000-00-00 00:00:00', 20),
('1', NULL, 0, NULL, '2023-05-14 13:29:06', '2023-05-14 13:37:47', NULL, 'Sujith ', 'Priyadashana', 'samankasumara@gmail.com', 'Employee', '0773051133', '$2y$10$6PVGQTM9D/bhleox0J1hZevftUDO6LD5kQiilMkzuBSdcGhIxBTuO', 'samankasumaragmailcom', '0000-00-00 00:00:00', 21),
('1', NULL, 0, NULL, '2023-05-15 11:14:10', '2023-05-16 13:39:35', NULL, 'Gimhana', 'Vihaga', 'gimhanavihaga@gmail.com', 'Employee', '0773051133', '$2y$10$rqt4DVuUIz7J0bjQkzT/3uHg8X.9fF/zKdUeUC7IRV80vRVXEpb/K', 'gimhanavihagagmailcom', '2023-05-16 08:09:35', 22),
(NULL, NULL, 0, NULL, '2023-05-15 22:48:52', '2023-05-15 22:53:34', NULL, 'Gimhana', 'Vimal', 'saman@gmail.com', 'Employee', '0773051133', '$2y$10$qMrMQXTWgQ7rmF/wjkdExuygZZiU9QLkEa15AodBUticf5yIsk5HK', 'samangmailcom', '0000-00-00 00:00:00', 23),
(NULL, NULL, 0, NULL, '2023-05-16 13:47:55', NULL, NULL, 'Jagath', 'Silva', 'jagath@gmail.com', 'Employee', '0773051133', '$2y$10$iuut/aCRFJNIY8o4zmvmouN9RB4vRxJPl7/hxNoKYdDuoSdEn3axS', 'jagathgmailcom', '0000-00-00 00:00:00', 24);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE `user_profile` (
  `date_of_birth` date NOT NULL,
  `apointment_date` datetime NOT NULL,
  `depatment` enum('Information Technology','Human Resources','Accounting','Sales','Admin') NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `qulifications` varchar(255) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `nationalid` varchar(12) NOT NULL,
  `nic_img` varchar(255) DEFAULT NULL,
  `empno` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `basic_salary` decimal(10,0) NOT NULL,
  `address` varchar(255) NOT NULL,
  `emagency_contact` varchar(10) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `designation` varchar(10) NOT NULL,
  `experience` varchar(20) DEFAULT NULL,
  `job_status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`date_of_birth`, `apointment_date`, `depatment`, `created`, `profile_updated`, `qulifications`, `gender`, `nationalid`, `nic_img`, `empno`, `uid`, `basic_salary`, `address`, `emagency_contact`, `contact_person`, `designation`, `experience`, `job_status`) VALUES
('2004-12-26', '0000-00-00 00:00:00', 'Information Technology', '2023-05-12 10:00:38', '0000-00-00 00:00:00', '5', 1, '19770231043', NULL, 1, 13, '250000', '386/B, Idigaslanda', '0711130511', 'Samana Hettiarachchi', '3', NULL, '2'),
('2004-12-27', '0000-00-00 00:00:00', 'Information Technology', '2023-05-12 10:13:39', '0000-00-00 00:00:00', '10', 1, '19770231055', NULL, 3, 12, '250000', 'No 36,  Colombo', '0711130511', 'Samana Hettiarachchi', '2', NULL, '3'),
('2004-12-27', '0000-00-00 00:00:00', 'Information Technology', '2023-05-12 10:16:13', '0000-00-00 00:00:00', '10', 1, '19770231046', NULL, 4, 14, '40000', 'No 36,  Colombo', '0711130511', 'Samana Hettiarachchi', '4', NULL, '2'),
('2004-12-28', '0000-00-00 00:00:00', 'Information Technology', '2023-05-12 10:19:03', '0000-00-00 00:00:00', '9', 1, '19770231049', NULL, 5, 15, '250000', 'No 36,  Colombo', '0711130511', 'Samana Hettiarachchi', '4', NULL, '4'),
('2004-12-28', '0000-00-00 00:00:00', 'Information Technology', '2023-05-12 10:23:06', '0000-00-00 00:00:00', '10', 1, '19770231057', NULL, 6, 16, '25000', 'No 36,  Colombo', '0711130511', 'Samana Hettiarachchi', '2', NULL, '4'),
('2004-12-27', '0000-00-00 00:00:00', 'Information Technology', '2023-05-13 16:39:24', '0000-00-00 00:00:00', '10', 1, '19770231010', NULL, 7, 18, '40000', 'No 36,  Colombo', '0711130511', 'Samana Hettiarachchi', '2', NULL, '3'),
('2002-12-11', '0000-00-00 00:00:00', 'Information Technology', '2023-05-13 16:41:06', '0000-00-00 00:00:00', '8', 1, '197702315123', NULL, 8, 17, '25000', '386/B, Idigaslanda', '0711130511', 'Samana Hettiarachchi', '4', NULL, '2'),
('2004-12-29', '0000-00-00 00:00:00', 'Information Technology', '2023-05-14 08:07:47', '0000-00-00 00:00:00', '9', 1, '197702301044', NULL, 9, 21, '25000', 'No. 386/B, Bopitiya, Pamunugama', '0773051133', 'Saman', '1', NULL, '3'),
('2004-12-26', '0000-00-00 00:00:00', 'Information Technology', '2023-05-15 05:46:21', '0000-00-00 00:00:00', '7', 1, '19770231023', NULL, 10, 22, '40000', 'No 36,  Colombo', '0711130511', 'Samana Hettiarachchi', '6', NULL, '1'),
('2004-12-27', '0000-00-00 00:00:00', 'Information Technology', '2023-05-16 08:34:58', '0000-00-00 00:00:00', '4', 1, '770231043V', NULL, 11, 1, '250000', '386/B, Idigaslanda', '0711130511', 'Samana Hettiarachchi', '4', NULL, '3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`a_id`),
  ADD KEY `empno` (`empno`);

--
-- Indexes for table `auth_logins`
--
ALTER TABLE `auth_logins`
  ADD PRIMARY KEY (`auth_id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `empno` (`empno`);

--
-- Indexes for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`empno`),
  ADD UNIQUE KEY `uid` (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `auth_logins`
--
ALTER TABLE `auth_logins`
  MODIFY `auth_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `empno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
